# Setup local – pas cu pas

Ghid pentru a rula proiectul pe Mac. Dacă ești pe Windows sau Linux, comenzile sunt similare dar pot diferi ușor.

---

## Ce ai nevoie înainte să începi

- **Docker Desktop** instalat și pornit (iconița să fie vizibilă în menu bar)
- **Python 3.10+** instalat (verifică cu `python3 --version` în Terminal)

---

## Pasul 1 – Descarcă proiectul

Descarcă ZIP-ul proiectului și dezarhivează-l în Downloads. Ar trebui să ai folderul:

```
~/Downloads/project_copy/
```

Verifică în Terminal:

```bash
ls ~/Downloads/project_copy/
```

Trebuie să vezi: `app.py`, `setup_database.py`, `generate_embeddings.py`, `seed_data.py`, `requirements.txt`, etc.

---

## Pasul 2 – Pornește Oracle Database în Docker

Deschide Terminal și rulează:

```bash
docker run -d \
  --name oracle-movie \
  -p 1522:1521 \
  -e ORACLE_PWD=MyPass123 \
  container-registry.oracle.com/database/free:latest
```

Dacă nu ai imaginea descărcată, Docker o descarcă automat (~3-4 GB, durează câteva minute).

Apoi verifică dacă baza de date a pornit:

```bash
docker logs -f oracle-movie
```

**Așteaptă** până vezi mesajul:

```
#########################
DATABASE IS READY TO USE!
#########################
```

Poate dura 2-5 minute. Când apare, apasă `Ctrl+C` ca să ieși din logs.

> **Dacă primești eroare că numele `oracle-movie` e deja folosit:**
> ```bash
> docker rm oracle-movie
> ```
> Apoi rulează din nou comanda `docker run` de mai sus.

---

## Pasul 3 – Creează userul în baza de date

```bash
docker exec -it oracle-movie sqlplus sys/MyPass123@FREEPDB1 as sysdba
```

Se deschide un prompt `SQL>`. Scrie pe rând:

```sql
CREATE USER movieuser IDENTIFIED BY moviepass;
GRANT CONNECT, RESOURCE, DB_DEVELOPER_ROLE TO movieuser;
ALTER USER movieuser QUOTA UNLIMITED ON USERS;
EXIT;
```

După fiecare linie apasă Enter. Trebuie să vezi `User created.`, `Grant succeeded.`, `User altered.`

---

## Pasul 4 – Instalează dependențele Python

```bash
cd ~/Downloads/project_copy
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install oracledb
pip install flask sentence-transformers python-dotenv
```

Ultimele comenzi durează câteva minute (descarcă torch, ~80 MB). E normal.

---

## Pasul 5 – Configurează conexiunea la baza de date

```bash
cp .env.example .env
sed -i '' 's/1521/1522/' .env
```

Asta creează fișierul `.env` și schimbă portul la 1522 (portul pe care rulează container-ul nostru Docker).

---

## Pasul 6 – Creează tabelele și inserează filmele

```bash
python setup_database.py
```

Trebuie să vezi:

```
✅ Setup complet! Rulați acum: python generate_embeddings.py
```

---

## Pasul 7 – Generează embeddings (vectorii)

```bash
python generate_embeddings.py
```

La prima rulare descarcă modelul AI (~80 MB). Apoi generează vectori pentru toate cele 50 de filme. La final trebuie să vezi:

```
✅ Embeddings generate și stocate cu succes!
```

> Avertismentul cu `ORA-51962` (vector memory area) se poate ignora – totul funcționează.

---

## Pasul 8 – Pornește aplicația

```bash
FLASK_PORT=5001 python app.py
```

> Folosim portul 5001 pentru că pe Mac portul 5000 e ocupat de AirPlay.

Deschide browserul la: **http://localhost:5001**

---

## Cum testezi

1. **Recomandări pe baza unui film** – alege un film din dropdown (ex: Inception), apasă „Recomandă"
2. **Căutare semantică** – scrie în câmpul de text, de exemplu:
   - `a movie about time travel and love`
   - `a dark story about revenge and obsession`
   - `animated movie about family and growing up`

Rezultatele apar cu procentaj de similaritate.

> Căutarea funcționează cel mai bine în engleză, pentru că descrierile filmelor sunt în engleză.

---

## Cum oprești totul

```bash
# Ctrl+C în terminalul cu app.py
deactivate
docker stop oracle-movie
```

## Cum repornești (nu mai trebuie setup)

```bash
docker start oracle-movie
# așteaptă ~30 secunde
cd ~/Downloads/project_copy
source venv/bin/activate
FLASK_PORT=5001 python app.py
```

---

## Probleme frecvente

| Problemă | Soluție |
|----------|---------|
| `DATABASE IS READY` nu apare | Așteaptă mai mult (până la 5 min). Verifică cu `docker ps` că containerul rulează. |
| `python-oracledb` nu se instalează | Folosește `pip install oracledb` (fără `python-` în față). |
| `HTTP ERROR 403` pe localhost:5000 | Pe Mac portul 5000 e ocupat. Folosește `FLASK_PORT=5001 python app.py`. |
| `LOB` error | Asigură-te că ai versiunile corecte de `app.py` și `generate_embeddings.py`. |
| `docker: name already in use` | Rulează `docker rm oracle-movie` apoi reîncearcă. |
