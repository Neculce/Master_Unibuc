import os

import oracledb
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template_string, request
from sentence_transformers import SentenceTransformer

load_dotenv()

app = Flask(__name__)

ORACLE_USER = os.getenv("ORACLE_USER", "movieuser")
ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD", "moviepass")
ORACLE_DSN = os.getenv("ORACLE_DSN", "localhost:1522/FREEPDB1")
MODEL_NAME = "all-MiniLM-L6-v2"

model = None
pool = None


def init_app():
    global model, pool

    print("Se încarcă modelul...")
    model = SentenceTransformer(MODEL_NAME)
    print("Model încărcat.")

    print("Se creează conexiunea la Oracle...")
    pool = oracledb.create_pool(
        user=ORACLE_USER,
        password=ORACLE_PASSWORD,
        dsn=ORACLE_DSN,
        min=2,
        max=5,
        increment=1
    )
    print("Conexiune realizată.")


def _clean(value):
    return value.read() if hasattr(value, "read") else value


def get_all_movies():
    with pool.acquire() as conn:
        cursor = conn.cursor()
        cursor.execute("""
                       SELECT id, title, genre, year, rating, description
                       FROM movies
                       ORDER BY title
                       """)
        columns = ["id", "title", "genre", "year", "rating", "description"]
        return [{k: _clean(v) for k, v in zip(columns, row)} for row in cursor.fetchall()]


def get_movie_by_id(movie_id):
    with pool.acquire() as conn:
        cursor = conn.cursor()
        cursor.execute("""
                       SELECT id, title, genre, year, rating, description
                       FROM movies
                       WHERE id = :id
                       """, {"id": movie_id})
        row = cursor.fetchone()

        if row:
            columns = ["id", "title", "genre", "year", "rating", "description"]
            return {k: _clean(v) for k, v in zip(columns, row)}

        return None


def get_recommendations_by_movie(movie_id, top_n=5):
    with pool.acquire() as conn:
        cursor = conn.cursor()
        cursor.execute("""
                       SELECT m.id,
                              m.title,
                              m.genre,
                              m.year,
                              m.rating,
                              m.description,
                              VECTOR_DISTANCE(
                                      mv.embedding,
                                      (SELECT embedding FROM movie_vectors WHERE movie_id = :mid),
                                      COSINE
                              ) AS distance
                       FROM movie_vectors mv
                                JOIN movies m ON m.id = mv.movie_id
                       WHERE mv.movie_id != :mid
                       ORDER BY VECTOR_DISTANCE(
                           mv.embedding,
                           (SELECT embedding FROM movie_vectors WHERE movie_id = :mid),
                           COSINE
                           )
                           FETCH FIRST :topn ROWS ONLY
                       """, {"mid": movie_id, "topn": top_n})

        columns = ["id", "title", "genre", "year", "rating", "description", "distance"]
        return [{k: _clean(v) for k, v in zip(columns, row)} for row in cursor.fetchall()]


def search_by_text(query_text, top_n=5):
    query_embedding = model.encode(query_text).tolist()
    vector_str = "[" + ",".join(str(x) for x in query_embedding) + "]"

    with pool.acquire() as conn:
        cursor = conn.cursor()
        cursor.execute("""
                       SELECT m.id,
                              m.title,
                              m.genre,
                              m.year,
                              m.rating,
                              m.description,
                              VECTOR_DISTANCE(mv.embedding, :qvec, COSINE) AS distance
                       FROM movie_vectors mv
                                JOIN movies m ON m.id = mv.movie_id
                       ORDER BY VECTOR_DISTANCE(mv.embedding, :qvec, COSINE)
                           FETCH FIRST :topn ROWS ONLY
                       """, {"qvec": vector_str, "topn": top_n})

        columns = ["id", "title", "genre", "year", "rating", "description", "distance"]
        return [{k: _clean(v) for k, v in zip(columns, row)} for row in cursor.fetchall()]


HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recomandare de filme</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fb;
            color: #1f2937;
            min-height: 100vh;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 24px;
        }

        header {
            text-align: center;
            padding: 36px 0 20px;
        }

        header h1 {
            font-size: 2.2em;
            color: #1f2937;
            margin-bottom: 10px;
        }

        header p {
            color: #6b7280;
            font-size: 1.02em;
            line-height: 1.5;
            max-width: 760px;
            margin: 0 auto;
        }

        .search-section {
            background: #ffffff;
            border-radius: 12px;
            padding: 22px;
            margin: 22px 0;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .search-section h2 {
            color: #111827;
            margin-bottom: 12px;
            font-size: 1.25em;
        }

        .section-text {
            color: #6b7280;
            margin-bottom: 14px;
            line-height: 1.5;
        }

        .search-row {
            display: flex;
            gap: 12px;
            margin-bottom: 8px;
        }

        .search-row input,
        .search-row select {
            flex: 1;
            padding: 12px 14px;
            border-radius: 10px;
            border: 1px solid #d1d5db;
            background: #ffffff;
            color: #1f2937;
            font-size: 1em;
        }

        .search-row input::placeholder {
            color: #9ca3af;
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            transition: background 0.2s ease;
            white-space: nowrap;
        }

        .btn-primary {
            background: #2563eb;
            color: #ffffff;
        }

        .btn-primary:hover {
            background: #1d4ed8;
        }

        .btn-secondary {
            background: #374151;
            color: #ffffff;
        }

        .btn-secondary:hover {
            background: #1f2937;
        }

        .section-title {
            color: #111827;
            margin: 30px 0 15px;
            font-size: 1.45em;
        }

        .movie-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 18px;
            margin: 20px 0;
        }

        .movie-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 18px;
            border: 1px solid #e5e7eb;
            transition: border-color 0.2s ease;
            cursor: pointer;
        }

        .movie-card:hover {
            border-color: #cbd5e1;
        }

        .movie-card h3 {
            font-size: 1.1em;
            margin-bottom: 8px;
            color: #111827;
        }

        .movie-meta {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 10px;
        }

        .tag {
            background: #f3f4f6;
            color: #374151;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75em;
        }

        .movie-desc {
            font-size: 0.9em;
            color: #6b7280;
            line-height: 1.5;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .recommendations {
            margin: 30px 0;
            padding: 22px;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .recommendations h2 {
            color: #111827;
            margin-bottom: 6px;
        }

        .recommendations .subtitle {
            color: #6b7280;
            margin-bottom: 18px;
            font-size: 0.95em;
            line-height: 1.5;
        }

        .rec-card {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            background: #f9fafb;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 12px;
            border: 1px solid #e5e7eb;
        }

        .rec-rank {
            min-width: 28px;
            color: #2563eb;
            font-size: 1em;
            font-weight: 700;
            padding-top: 2px;
        }

        .rec-info {
            flex: 1;
        }

        .rec-info h3 {
            color: #111827;
            margin-bottom: 4px;
            font-size: 1.04em;
        }

        .rec-info .rec-meta {
            color: #6b7280;
            font-size: 0.9em;
            margin-bottom: 8px;
        }

        .rec-desc {
            color: #6b7280;
            font-size: 0.9em;
            line-height: 1.5;
        }

        .rec-score {
            min-width: 110px;
            text-align: right;
            color: #2563eb;
            font-size: 0.9em;
            font-weight: 600;
        }

        .loading {
            text-align: center;
            padding: 30px;
            display: none;
            color: #6b7280;
        }

        .spinner {
            width: 36px;
            height: 36px;
            border: 4px solid #e5e7eb;
            border-top-color: #2563eb;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .footer {
            text-align: center;
            padding: 36px 20px;
            color: #6b7280;
            font-size: 0.9em;
        }

        .footer p {
            margin-top: 6px;
        }

        @media (max-width: 768px) {
            .search-row {
                flex-direction: column;
            }

            .rec-card {
                flex-direction: column;
            }

            .rec-score {
                text-align: left;
                min-width: auto;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Recomandare de filme</h1>
            <p>Caută filme similare pornind de la o descriere sau de la un titlu deja existent.</p>
        </header>

        <div class="search-section">
            <h2>Căutare după descriere</h2>
            <p class="section-text">
                Scrie câteva cuvinte despre tipul de film căutat.
            </p>
            <div class="search-row">
                <input type="text" id="searchInput"
                       placeholder="Ex: un film despre familie, speranță și sacrificiu"
                       onkeypress="if(event.key==='Enter') searchByText()">
                <button class="btn btn-primary" onclick="searchByText()">Caută</button>
            </div>
        </div>

        <div class="search-section">
            <h2>Recomandări pe baza unui film selectat</h2>
            <p class="section-text">
                Selectează un film pentru a vedea recomandări similare.
            </p>
            <div class="search-row">
                <select id="movieSelect">
                    <option value="">-- Alege un film --</option>
                    {% for movie in movies %}
                    <option value="{{ movie.id }}">{{ movie.title }} ({{ movie.year }})</option>
                    {% endfor %}
                </select>
                <button class="btn btn-secondary" onclick="getRecommendations()">Vezi recomandări</button>
            </div>
        </div>

        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p>Se procesează cererea...</p>
        </div>

        <div id="results"></div>

        <h2 class="section-title">Toate filmele din baza de date</h2>
        <div class="movie-grid">
            {% for movie in movies %}
            <div class="movie-card" onclick="selectMovie({{ movie.id }})">
                <h3>{{ movie.title }}</h3>
                <div class="movie-meta">
                    <span class="tag">{{ movie.genre }}</span>
                    <span class="tag">{{ movie.year }}</span>
                    <span class="tag">Rating: {{ movie.rating }}</span>
                </div>
                <p class="movie-desc">{{ movie.description }}</p>
            </div>
            {% endfor %}
        </div>

        <div class="footer">
            <p>Proiect realizat în cadrul cursului Topici Speciale în Baze de Date și Tehnologii Web</p>
            <p>Oracle Database · Flask · Sentence Transformers</p>
        </div>
    </div>

    <script>
        function selectMovie(id) {
            document.getElementById('movieSelect').value = id;
            getRecommendations();
        }

        async function getRecommendations() {
            const movieId = document.getElementById('movieSelect').value;

            if (!movieId) {
                alert('Selectează un film.');
                return;
            }

            showLoading();

            try {
                const res = await fetch(`/api/recommend/${movieId}`);
                const data = await res.json();

                displayResults(
                    `Recomandări pentru "${data.source_movie.title}"`,
                    'Filme similare cu titlul ales.',
                    data.recommendations
                );
            } catch (err) {
                document.getElementById('results').innerHTML =
                    '<p style="color:#dc2626;">A apărut o eroare la obținerea recomandărilor.</p>';
            }

            hideLoading();
        }

        async function searchByText() {
            const query = document.getElementById('searchInput').value.trim();

            if (!query) {
                alert('Scrie o descriere.');
                return;
            }

            showLoading();

            try {
                const res = await fetch('/api/search', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query: query })
                });

                const data = await res.json();

                displayResults(
                    `Rezultate pentru: "${query}"`,
                    'Rezultatele cele mai relevante pentru căutarea introdusă.',
                    data.results
                );
            } catch (err) {
                document.getElementById('results').innerHTML =
                    '<p style="color:#dc2626;">A apărut o eroare la căutare.</p>';
            }

            hideLoading();
        }

        function displayResults(title, subtitle, items) {
            let html = `
                <div class="recommendations">
                    <h2>${title}</h2>
                    <p class="subtitle">${subtitle}</p>
            `;

            items.forEach((item, i) => {
                const similarity = ((1 - item.distance) * 100).toFixed(1);

                html += `
                    <div class="rec-card">
                        <div class="rec-rank">${i + 1}.</div>
                        <div class="rec-info">
                            <h3>${item.title}</h3>
                            <div class="rec-meta">${item.genre} · ${item.year} · Rating: ${item.rating}</div>
                            <p class="rec-desc">${item.description.substring(0, 150)}...</p>
                        </div>
                        <div class="rec-score">${similarity}%</div>
                    </div>
                `;
            });

            html += '</div>';
            document.getElementById('results').innerHTML = html;
            document.getElementById('results').scrollIntoView({ behavior: 'smooth' });
        }

        function showLoading() {
            document.getElementById('loading').style.display = 'block';
        }

        function hideLoading() {
            document.getElementById('loading').style.display = 'none';
        }
    </script>
</body>
</html>
"""


@app.route("/")
def index():
    movies = get_all_movies()
    return render_template_string(HTML_TEMPLATE, movies=movies)


@app.route("/api/recommend/<int:movie_id>")
def api_recommend(movie_id):
    source = get_movie_by_id(movie_id)

    if not source:
        return jsonify({"error": "Film negăsit"}), 404

    recommendations = get_recommendations_by_movie(movie_id, top_n=5)
    return jsonify({
        "source_movie": source,
        "recommendations": recommendations
    })


@app.route("/api/search", methods=["POST"])
def api_search():
    data = request.get_json()
    query = data.get("query", "").strip()

    if not query:
        return jsonify({"error": "Query gol"}), 400

    results = search_by_text(query, top_n=5)
    return jsonify({
        "query": query,
        "results": results
    })


@app.route("/api/movies")
def api_movies():
    return jsonify(get_all_movies())


if __name__ == "__main__":
    init_app()
    host = os.getenv("FLASK_HOST", "0.0.0.0")
    port = int(os.getenv("FLASK_PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "True").lower() == "true"

    print(f"Aplicația pornește la http://localhost:{port}")
    app.run(host=host, port=port, debug=debug, use_reloader=False)