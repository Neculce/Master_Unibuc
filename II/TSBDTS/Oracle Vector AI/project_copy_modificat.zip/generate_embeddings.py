
import oracledb
import os
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

load_dotenv()

ORACLE_USER = os.getenv("ORACLE_USER", "movieuser")
ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD", "moviepass")
ORACLE_DSN = os.getenv("ORACLE_DSN", "localhost:1522/FREEPDB1")

# Modelul de embedding - produce vectori de 384 dimensiuni
MODEL_NAME = "all-MiniLM-L6-v2"


def get_connection():
    return oracledb.connect(
        user=ORACLE_USER,
        password=ORACLE_PASSWORD,
        dsn=ORACLE_DSN
    )


def main():
    print("=" * 60)
    print("Generare Embeddings - Movie Recommender")
    print("=" * 60)

    # 1. Încărcare model
    print(f"\n[1] Încărcare model '{MODEL_NAME}'...")
    model = SentenceTransformer(MODEL_NAME)
    print("  Model încărcat cu succes!")

    # 2. Conectare la DB
    print("\n[2] Conectare la Oracle DB...")
    conn = get_connection()
    cursor = conn.cursor()
    print("  Conectat!")

    # 3. Golire vectori existenți
    print("\n[3] Ștergere vectori existenți...")
    cursor.execute("DELETE FROM movie_vectors")
    conn.commit()
    print("  Vectori vechi șterși.")

    # 4. Obținere filme
    print("\n[4] Obținere filme din baza de date...")
    cursor.execute("SELECT id, title, description FROM movies ORDER BY id")
    movies = cursor.fetchall()
    print(f"  {len(movies)} filme găsite.")

    # 5. Generare și stocare embeddings
    print("\n[5] Generare embeddings...")
    descriptions = [v.read() if hasattr(v, 'read') else str(v) for (_, _, v) in movies]

    # Batch encoding - mult mai eficient decât per film
    embeddings = model.encode(descriptions, show_progress_bar=True)

    print("\n[6] Stocare embeddings în Oracle DB...")
    for i, (movie_id, title, _) in enumerate(movies):
        # Convertire numpy array → lista Python → string format vector Oracle
        embedding_list = embeddings[i].tolist()
        vector_str = "[" + ",".join(str(x) for x in embedding_list) + "]"

        cursor.execute("""
            INSERT INTO movie_vectors (movie_id, embedding)
            VALUES (:mid, :emb)
        """, {"mid": movie_id, "emb": vector_str})

        print(f"  ✓ [{i+1}/{len(movies)}] {title}")

    conn.commit()

    # 7. Creare index HNSW (dacă nu există)
    print("\n[7] Creare index HNSW...")
    try:
        cursor.execute("""
            CREATE VECTOR INDEX idx_movie_vectors_hnsw
            ON movie_vectors(embedding)
            ORGANIZATION INMEMORY NEIGHBOR GRAPH
            DISTANCE COSINE
            WITH TARGET ACCURACY 95
        """)
        print("  Index HNSW creat cu succes!")
    except oracledb.DatabaseError as e:
        if "ORA-00955" in str(e):  # index already exists
            print("  Index HNSW exista deja, skip.")
        else:
            print(f"  Avertisment la creare index: {e}")

    # 8. Verificare
    print("\n[8] Verificare...")
    cursor.execute("SELECT COUNT(*) FROM movie_vectors")
    count = cursor.fetchone()[0]
    print(f"  Total vectori stocați: {count}")

    # Test rapid de similaritate
    print("\n[9] Test rapid de similaritate...")
    cursor.execute("""
        SELECT m.title,
               VECTOR_DISTANCE(mv.embedding,
                   (SELECT embedding FROM movie_vectors WHERE movie_id = 1),
                   COSINE) AS distance
        FROM movie_vectors mv
        JOIN movies m ON m.id = mv.movie_id
        WHERE mv.movie_id != 1
        ORDER BY distance
        FETCH FIRST 3 ROWS ONLY
    """)
    print("  Top 3 filme similare cu 'The Shawshank Redemption':")
    for row in cursor.fetchall():
        print(f"    - {row[0]} (distanță cosinus: {row[1]:.4f})")

    cursor.close()
    conn.close()
    print("\n✅ Embeddings generate și stocate cu succes!")
    print("   Rulați acum: python app.py")


if __name__ == "__main__":
    main()