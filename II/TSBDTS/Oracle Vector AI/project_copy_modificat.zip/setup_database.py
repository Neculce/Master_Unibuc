import oracledb
import os
from dotenv import load_dotenv
from seed_data import MOVIES

load_dotenv()

ORACLE_USER = os.getenv("ORACLE_USER", "movieuser")
ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD", "moviepass")
ORACLE_DSN = os.getenv("ORACLE_DSN", "localhost:1522/FREEPDB1")


def get_connection():
    return oracledb.connect(
        user=ORACLE_USER,
        password=ORACLE_PASSWORD,
        dsn=ORACLE_DSN
    )


def drop_tables_if_exist(cursor):
    for table in ["movie_vectors", "movies"]:
        try:
            cursor.execute(f"DROP TABLE {table} CASCADE CONSTRAINTS PURGE")
            print(f"  Tabel '{table}' șters.")
        except oracledb.DatabaseError:
            print(f"  Tabel '{table}' nu exista, skip.")


def create_tables(cursor):
    cursor.execute("""
        CREATE TABLE movies (
            id          NUMBER(10) GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            title       VARCHAR2(500)   NOT NULL,
            genre       VARCHAR2(200)   NOT NULL,
            year        NUMBER(4)       NOT NULL,
            description CLOB            NOT NULL,
            rating      NUMBER(3,1)     DEFAULT 0
        )
    """)
    print("  Tabel 'movies' creat.")

    cursor.execute("""
        CREATE TABLE movie_vectors (
            movie_id    NUMBER(10) NOT NULL,
            embedding   VECTOR(384, FLOAT32),
            CONSTRAINT fk_movie FOREIGN KEY (movie_id)
                REFERENCES movies(id) ON DELETE CASCADE
        )
    """)
    print("  Tabel 'movie_vectors' creat.")


def insert_movies(cursor, connection):
    for movie in MOVIES:
        cursor.execute("""
            INSERT INTO movies (title, genre, year, description, rating)
            VALUES (:title, :genre, :year, :description, :rating)
        """, {
            "title": movie["title"],
            "genre": movie["genre"],
            "year": movie["year"],
            "description": movie["description"],
            "rating": movie["rating"]
        })
    connection.commit()
    print(f"  {len(MOVIES)} filme inserate.")


def main():
    print("=" * 60)
    print("Setup Database - Movie Recommender (Oracle AI Vector Search)")
    print("=" * 60)

    print("\n[1] Conectare la Oracle DB...")
    conn = get_connection()
    cursor = conn.cursor()
    print("  Conectat cu succes!")

    print("\n[2] Ștergere tabele existente...")
    drop_tables_if_exist(cursor)

    print("\n[3] Creare tabele noi...")
    create_tables(cursor)

    print("\n[4] Inserare filme...")
    insert_movies(cursor, conn)

    print("\n[5] Verificare...")
    cursor.execute("SELECT COUNT(*) FROM movies")
    count = cursor.fetchone()[0]
    print(f"  Total filme în baza de date: {count}")

    cursor.close()
    conn.close()
    print("\n✅ Setup complet! Rulați acum: python generate_embeddings.py")


if __name__ == "__main__":
    main()
